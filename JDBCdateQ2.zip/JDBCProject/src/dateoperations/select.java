package dateoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc.util.JdbcConnection;

public class select {

	public static void main(String[] args) throws SQLException {
		Connection con =null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter sname to view details: ");
		String uname = sc.next();
		
		String query = "select uname,uadd,dob,doj,dom from user where uname=?";
		
		try {
			con = JdbcConnection.getconnection();
			if(con!=null)
				pst = con.prepareStatement(query);  
			if(pst!=null) {
				pst.setString(1, uname);
				rs = pst.executeQuery();
				if(rs!=null) {
					
					 
					if(rs.next()) {
						System.out.println("UNAME\tUADD\tUDOB\t\tUDOJ\t\tUDOM");
						System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getDate(3)+"\t"+rs.getDate(4)+"\t"+rs.getDate(5));
					}
					else {
						System.out.println("record for given id= "+uname+" not found");
					}
				}
					
				
			}
			}finally {
				JdbcConnection.closeconnection(con, pst, rs);
				if(sc!=null)
					sc.close();
				
			}
		

	}

	

}
