package dateoperations;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

import jdbc.util.Dateformat;
import jdbc.util.JdbcConnection;

public class insertdate {

	public static void main(String[] args) throws ParseException, SQLException {
		Connection con =null;
		PreparedStatement pst =null;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter user name: ");
		String uname = sc.next();
		
		System.out.println("enter user uadd: ");
		String uadd = sc.next();
		
		//take input as string
		System.out.println("enter user DOB(dd-MM-yyyy): ");
		String sdob = sc.next();
		String format = "dd-MM-yyyy";
		Date sqldob = Dateformat.formatdate(sdob,format);
		
		System.out.println("enter user DOJ(MM-dd-yyyy): ");
		String sdoj = sc.next();
		String format1 = "MM-dd-yyyy";
		Date sqldoj = Dateformat.formatdate(sdoj,format1);
		
		System.out.println("enter user DOM(yyyy-MM-dd): ");
		String sdom = sc.next();
		String format2 = "yyyy-MM-dd";
		Date sqldom = Dateformat.formatdate(sdom,format2);
		
	
		 
		String query = "insert into user(`uname`,`uadd`,`dob`,`doj`,`dom`) values(?,?,?,?,?)";
		
		try {
		con = JdbcConnection.getconnection();
		if(con!=null) {
			pst = con.prepareStatement(query);
			pst.setString(1, uname);
			pst.setString(2, uadd);
			pst.setDate(3, sqldob);
			pst.setDate(4, sqldoj);
			pst.setDate(5, sqldom);
			
			}
		if(pst!=null) {
			int rowsaffected = pst.executeUpdate();
			System.out.println("no of rows affected : "+rowsaffected);
			
		}
		}finally {
			JdbcConnection.closeconnection(con, pst, null);
			if(sc!=null)
				sc.close();
			
		}
		
		

	}

}
