package jdbc.util;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Dateformat {
	public static Date formatdate(String sdob,String format) throws ParseException {
		
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		java.util.Date uDate = sdf.parse(sdob);

		long time = uDate.getTime();
		java.sql.Date sqlDate = new java.sql.Date(time);
		return sqlDate;
		
	}
}
