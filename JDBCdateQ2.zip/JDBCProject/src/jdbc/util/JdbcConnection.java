/**
 * 
 */
package jdbc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author harik
 *java database connection
 *
 */
public class JdbcConnection {
	
	public static Connection getconnection() throws SQLException {
		
		Connection con = null;
		
		
		String url = "jdbc:mysql://localhost:3306/db1";
		String uname = "root";
		String password = "root";
		
		con = DriverManager.getConnection(url,uname,password);
		
		if(con!=null) {
			return con;
		} 
		else
			return con;
	}
	
	public static void closeconnection(Connection con, Statement pst, ResultSet rs) throws SQLException {
		if(con!=null) {
			con.close();
		} 
		
		if(pst!=null) {
			pst.close();
		}
		if(rs!=null) {
			rs.close();
		}
		
	}

}
