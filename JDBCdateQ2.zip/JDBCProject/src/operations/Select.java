package operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc.util.JdbcConnection;

public class Select {

	public static void main(String[] args) throws SQLException {
		Connection con =null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter sid to view details: ");
		int sid = sc.nextInt();
		
		String query = "select sid,sname,sadd,sgen from student where sid=?";
		
		try {
			con = JdbcConnection.getconnection();
			if(con!=null)
				pst = con.prepareStatement(query);  
			if(pst!=null) {
				pst.setInt(1, sid);
				rs = pst.executeQuery();
				if(rs!=null) {
					
					
					if(rs.next()) {
						System.out.println("SID\tSNAME\tSADD\tSGEN");
						System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));
					}
					else {
						System.out.println("record for given id= "+sid+" not found");
					}
				}
					
				
			}
			}finally {
				JdbcConnection.closeconnection(con, pst, rs);
				if(sc!=null)
					sc.close();
				
			}
		

	}

}
