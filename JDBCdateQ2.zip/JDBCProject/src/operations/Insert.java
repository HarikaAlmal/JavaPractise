package operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc.util.JdbcConnection;

public class Insert {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection con =null;
		PreparedStatement pst = null;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter sid: ");
		int sid = sc.nextInt();
		System.out.println("enter sname: ");
		String sname = sc.next();
		System.out.println("enter sadd: ");
		String sadd = sc.next();
		System.out.println("enter sgen: ");
		String sgen = sc.next();
		 
		
		String query = "insert into student(`sid`,`sname`,`sadd`,`sgen`) values(?,?,?,?)";
		
		try {
		con = JdbcConnection.getconnection();
		if(con!=null)
			pst = con.prepareStatement(query); 
		if(pst!=null) {
			pst.setInt(1, sid);
			pst.setString(2, sname);
			pst.setString(3, sadd);
			pst.setString(4, sgen);
			
			int rowsAffected = pst.executeUpdate();
			System.out.println("no of row affected: "+rowsAffected); 
		}
		}finally {
			JdbcConnection.closeconnection(con, pst, null);
			if(sc!=null)
				sc.close();
			
		}

	}

}
