package operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc.util.JdbcConnection;

public class Update {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection con =null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter sid to update details: ");
		int sid = sc.nextInt();
		
		System.out.println("enter sadd to update where sid= :"+sid);
		String sadd = sc.next();
		
		String query = "update student SET sadd=? where sid=?";
		
		try {
		con =JdbcConnection.getconnection();
		if(con!=null) {
			pst = con.prepareStatement(query); 
		}
		if(pst!=null) {
			pst.setString(1, sadd);
			pst.setInt(2, sid);
			int rowsaffected = pst.executeUpdate();
			System.out.println("no of rows affected: "+rowsaffected);
		}
		}finally {
			JdbcConnection.closeconnection(con, pst, null);
			if(sc!=null)
				sc.close();
		}
		

	}

}
