package operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc.util.JdbcConnection;

public class Delete {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection con =null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter sid to delete details: ");
		int sid = sc.nextInt();
		
		
		
		String query = "delete from student where sid=?";
		
		try {
		con =JdbcConnection.getconnection();
		if(con!=null) {
			pst = con.prepareStatement(query); 
		}
		if(pst!=null) {
			pst.setInt(1, sid);
			
			int rowsaffected = pst.executeUpdate();
			System.out.println("no of rows affected: "+rowsaffected);
		}
		}finally {
			JdbcConnection.closeconnection(con, pst, null);
			if(sc!=null)
				sc.close();
		}
		

	}
		

	

}
