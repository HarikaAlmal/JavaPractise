package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

class Jdbcclass {
  public static void main(String[] args) throws ClassNotFoundException, SQLException {
    Connection con = null;
    Statement stmt = null;
	/*
	 * Driver dr = new Driver(); DriverManager.registerDriver(dr);
	 */

    String url = "jdbc:mysql://localhost:3306/db1";
    String username = "root";
    String password = "root";

    try {
      //Class.forName("com.mysql.cj.jdbc.Driver");
      con = DriverManager.getConnection(url, username, password);
      if(con!=null) {
    	  stmt=con.createStatement();
      }
      Scanner sc = new Scanner(System.in);
     
      System.out.println("1:to create ");
      System.out.println("2:select ");
      System.out.println("3:insert");
      System.out.println("4:update");
      System.out.println("5:delete");
      System.out.println("enter user input: ");
      int input = sc.nextInt();
      
      switch(input) {
      case 1:
    	  stmt.executeUpdate("create table Person(id INTEGER,name varchar(255),address varchar(255),ph INTEGER)");  
	      
	      System.out.println("Table created");  
	      break;//con.close();  
      case 2:
    	  ResultSet rs2=stmt.executeQuery("select * from Person");  
    	
	      while(rs2.next())  
	      System.out.println(rs2.getInt(1)+" "+rs2.getString(2)+" "+rs2.getString(3)+" "+rs2.getInt(4));break;
      case 3:
    	  int rs3=stmt.executeUpdate("insert into Person values(2,'Haari','Home',9876)");  
	       
	      System.out.println("no of rows effected: "+rs3 );break;
      case 4:
    	  int rs4=stmt.executeUpdate("update Person SET ph=4321 WHERE id = 1");  
    	  
	      System.out.println("no of rows effected: "+rs4 );   break;
	      
      case 5:
    	  //int rs4=stmt.executeUpdate("update Person SET ph=4321 WHERE id = 1");  
    	  int rs5=stmt.executeUpdate("delete from Person"); 
	      System.out.println("no of rows effected: "+rs5 );   break;
	       
	       
	     
      }
      

      //System.out.println("Connected!");

    } catch (SQLException ex) {
        throw new Error("Error ", ex);
    } finally {
      try {
        if (con != null) {
            con.close();
        }
        if (stmt != null) {
            stmt.close();
        }
        
      } catch (SQLException ex) {
          System.out.println(ex.getMessage());
      }
    }
  }
}